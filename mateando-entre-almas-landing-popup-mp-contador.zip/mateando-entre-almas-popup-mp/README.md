# Landing Page - Mateando entre Almas

Proyecto completo mobile first con HTML5, CSS3, JavaScript y SweetAlert2.

## Flujo MercadoPago corregido con popup + contador

1. El cliente elige MercadoPago.
2. Se abre un popup con el checkout de MercadoPago.
3. El popup tiene cruz para cerrar.
4. Muestra un contador regresivo de 10 segundos.
5. Al finalizar, redirige automáticamente al formulario:

```txt
checkout.html?method=mercadopago&paid=1
```

6. El cliente completa los datos de envío.
7. Se genera WhatsApp al vendedor y copia por email mediante `mailto:`.

## Dónde modificar el contador

Abrir:

```txt
assets/js/config.js
```

Modificar:

```js
MERCADOPAGO_POPUP_SECONDS: 10
```

## MercadoPago

Checkout configurado:

```txt
https://mpago.la/16pt2s3
```

Importante: MercadoPago puede bloquear la carga dentro del iframe por seguridad. Por eso el popup incluye el botón:

```txt
Abrir MercadoPago en nueva pestaña
```

## Transferencia

Banco ICBC  
Alias: FERNANDOMATA420YOYER  
Titular: Ing. Fernando M. Gambino  
CUIL: 20-34185420-4  

## Imagen del libro

Editar:

```txt
assets/js/config.js
```

Variable:

```js
BOOK_IMAGE_URL
```

## Plazos informados

- Despacho dentro de los 7 días por plazos de producción.
- Transporte Correo Argentino: 7 a 10 días.

## Casilla obligatoria

El cliente debe marcar:

```txt
He leído y acepto los plazos de producción, despacho y transporte informados.
```
