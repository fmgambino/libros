/*
  CONFIGURACIÓN RÁPIDA

  BOOK_IMAGE_URL:
  Reemplazá por la URL real de la portada.

  SITE_BASE_URL:
  Reemplazá por el dominio real donde subas esta landing.

  MERCADOPAGO_POPUP_SECONDS:
  Modificá aquí el contador del popup de MercadoPago.
*/

const STORE_CONFIG = {
  BOOK_TITLE: "Mateando entre Almas",
  AUTHOR: "F. M. Gambino",

  // 👉 COLOCAR AQUÍ LA URL DE LA IMAGEN DEL LIBRO
  BOOK_IMAGE_URL: "https://TU-DOMINIO.com/ruta/portada-mateando-entre-almas.jpg",

  // 👉 COLOCAR AQUÍ EL DOMINIO REAL DONDE SUBAS ESTA LANDING
  SITE_BASE_URL: "https://TU-DOMINIO.com/mateando-entre-almas",

  BOOK_PRICE: 18000,
  SHIPPING_PRICE: 12000,
  MERCADOPAGO_PERCENT: 15,

  SELLER_EMAIL: "fernando.m.gambino@gmail.com",
  SELLER_WHATSAPP_NUMBER: "543816150488",

  MERCADOPAGO_CHECKOUT_URL: "https://mpago.la/16pt2s3",

  // 👉 MODIFICAR AQUÍ EL CONTADOR DEL POPUP DE MERCADOPAGO
  MERCADOPAGO_POPUP_SECONDS: 10,

  PAYMENT_TRANSFER_INFO:
    "Banco ICBC\nAlias: FERNANDOMATA420YOYER\nTitular: Ing. Fernando M. Gambino\nCUIL: 20-34185420-4"
};

function getMercadoPagoReturnUrl() {
  return `${STORE_CONFIG.SITE_BASE_URL.replace(/\/$/, "")}/checkout.html?method=mercadopago&paid=1`;
}
